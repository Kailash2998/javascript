// que no:-01
function find_date() {
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1;
    var yyyy = today.getFullYear();
    if (dd < 10) {
        dd = '0' + dd;
    }

    if (mm < 10) {
        mm = '0' + mm;
    }

    if (document.getElementById('Date1').checked) {
        today = mm + '-' + dd + '-' + yyyy;
    }
    else if (document.getElementById('Date2').checked) {
        today = mm + '/' + dd + '/' + yyyy;

    }
    else if (document.getElementById('Date3').checked) {
        today = dd + '-' + mm + '-' + yyyy;
    }
    else {
        today = dd + '/' + mm + '/' + yyyy;

    }
    document.getElementById('today').innerHTML = "Date is: " + today;
}

// Que no:-02 
function show_section(sel_option) {
    document.getElementById('div_city').style.display = 'block';

    if (sel_option == 'india') {
        document.getElementById('country_india').style.display = 'block';
        document.getElementById('country_usa').style.display = 'none';
        document.getElementById('country_UK').style.display = 'none';
        document.getElementById('country_india').focus();

    }
    else if (sel_option == 'china') {
        document.getElementById('country_india').style.display = 'none';
        document.getElementById('country_usa').style.display = 'none';
        document.getElementById('country_UK').style.display = 'block';
        document.getElementById('country_UK').focus();
    }
    else if (sel_option == 'usa') {
        document.getElementById('country_india').style.display = 'none';
        document.getElementById('country_usa').style.display = 'block';
        document.getElementById('country_UK').style.display = 'none';
        document.getElementById('country_usa').focus();
    }
}
function show_city(sel_city) {
    document.getElementById('sel_show_city').innerHTML = 'Selected City is :' + sel_city;
}

// Que no:-03
	function color(){
		var selected = [];
		var ele = document.getElementsByName('chk');
		// var all_checked = true;
		for (var index = 0; index < ele.length; index++){
			if(ele[index].type == 'checkbox' && ele[index].checked == true) {
				selected.push(ele[index].value);
			}    
		} 
      document.getElementById('sel_color').innerHTML = 'Selected color: ' + selected.length ;
	}

// Que no:-04
function deleteRow(button) {
   var confirmation = confirm("Are you sure you want to delete this row?");
   if (confirmation) {
     var row = button.parentNode.parentNode;
     row.parentNode.removeChild(row);
   }
 }