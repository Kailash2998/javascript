$(document).ready(function () {
	//custom validation
	jQuery.validator.addMethod("lettersonly", function (value, element) {
			return this.optional(element) || /^[a-z ]+$/i.test(value);
	}, "Letters and space only please");

	//form validation
	$("#basic-form").validate({
			rules: {
					username: {
							required: true,
							minlength: 3,
							maxlength: 12,
							lettersonly: true
					},
					city_name: {
							required: true,
							minlength: 3,
							maxlength: 12,
							lettersonly: true
					},
					password: {
							required: true,
							minlength: 6,
							maxlength: 12
					},
					server: {
							required: true
					},
					role: {
							required: true
					},
					signin: {
							required: true
					}
			},
			messages:
			{
					username: {
							required: 'Please enter username',
							minlength: 'Please enter minimum 3 letters',
							maxlength: 'Please enter maximum 12 letters',
							lettersonly: 'Please enter only letters and spaces'
					},
					city_name: {
							required: 'Please enter city name',
							minlength: 'Please enter minimum 3 letters',
							maxlength: 'Please enter maximum 12 letters',
							lettersonly: 'Please enter only letters and spaces'
					},
					password: {
							required: 'Please enter password',
							minlength: 'Please enter minimum 6 letters',
							maxlength: 'Please enter maximum 12 letters'
					},
					server: {
							required: 'Please select server'
					},
					role: {
							required: 'Please select role'
					},
					signin:{
							required: 'Please select sign-in'
					}
			},
			errorPlacement: function (error, element) {
					if (element.is(":radio")) {
							error.appendTo('#role_err');
					} else if (element.is(":checkbox")) {
							error.appendTo('#signing_err');
					} else { // This is the default behavior 
							error.insertAfter(element);
					}
			},
	});
});
