//function for frame & shape
var price;
function show_section(sel_option) {
	document.getElementById('div_shape').style.display = 'block';

	if (sel_option == 'FillRim') {
		document.getElementById('FillRim').style.display = 'block';
		document.getElementById('HalflRim').style.display = 'none';
		document.getElementById('Rimless').style.display = 'none';
		document.getElementById('FillRim').focus();

	}
	else if (sel_option == 'Rimless') {
		document.getElementById('FillRim').style.display = 'none';
		document.getElementById('HalflRim').style.display = 'none';
		document.getElementById('Rimless').style.display = 'block';
		document.getElementById('Rimless').focus();
	}
	else if (sel_option == 'HalfRim') {
		document.getElementById('FillRim').style.display = 'none';
		document.getElementById('HalflRim').style.display = 'block';
		document.getElementById('Rimless').style.display = 'none';
		document.getElementById('HalflRim').focus();
	}
}

function show_shape(sel_shape) {
	switch (sel_shape) {
		case 'FillRim-round': document.getElementById('face_img').src = 'assets/images/image1.jpg';price=1000;
			break;

		case 'FillRim-square': img_src = document.getElementById('face_img').src = 'assets/images/image2.jpg';price=800;
			break;

		case 'FillRim-rectangle': document.getElementById('face_img').src = 'assets/images/image3.jpg';price=1000;
			break;

		case 'HalflRim-round': document.getElementById('face_img').src = 'assets/images/image4.jpg';price=800;
			break;

		case 'HalflRim-square': document.getElementById('face_img').src = 'assets/images/image5.jpg';price=1000;
			break;

		case 'HalflRim-rectangle': document.getElementById('face_img').src = 'assets/images/image6.jpg';price=800;
			break;

		case 'Rimless-round': document.getElementById('face_img').src = 'assets/images/image7.jpg';price=1000;
			break;

		case 'Rimless-square': document.getElementById('face_img').src = 'assets/images/image8.jpg';price=800;
			break;

		case 'Rimless-rectangle': document.getElementById('face_img').src = 'assets/images/image9.jpg';price=1000;
			break;
		default: comment = 'Scope to improve';
	}
	document.getElementById('sel_show_shape').innerHTML = 'Selected frame price is : ' +' '+price+'Rs';

}

//function for quantity and price
$(document).ready(function() {
	$('#but_show').click(function(event) {
		var type_1 = $('#car_type').find(":selected").val();
  
	  var quantity = parseInt($('#quantity').val());
	  var total = quantity * price;
	  $('#result').html('Total Price: ' + total.toFixed(2));
	  $('#modal_disp').modal('show');
	  $('#price').html(price);
	  $('#quantity2').html(quantity);
	  $('#total').html(total);
	});
  });

  $("#modal_disp").on('hide.bs.modal', function () {
	console.log("test");
	// $.alert({
	// 	title: 'Success',
	// 	content: 'The form has been submitted successfully',
	// });
});
