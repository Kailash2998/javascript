// Que no :1
function Fullname()
{
    var firstname = document.getElementById("fname").value;
    var lastname = document.getElementById("lname").value;

    var cap_firstname = firstname.charAt(0).toUpperCase()+firstname.slice(1).toLowerCase();
    var cap_lastname = lastname.charAt(0).toUpperCase()+lastname.slice(1).toLowerCase();

    var full_name = cap_firstname+" "+cap_lastname;
    document.getElementById("output1").innerText=full_name;
}
	 
// Que no :2
function Displaystring()
{
    var Acceptstring= document.getElementById("Acceptstring").value;
    var Wordtoreplace = document.getElementById("Wordtoreplace").value;
    var Newword = document.getElementById("Newword").value;

    var ChangedString =  Acceptstring.replace(Wordtoreplace , Newword);
    
    document.getElementById("output2").innerText= ChangedString;
}

// Que no :3
function Reversedword()
{
    var InputWord = document.getElementById("Input-Word").value;
    var Reversedword = InputWord.split("").reverse().join("");

    document.getElementById("output3").innerText= Reversedword ;
}

// Que no :4
function Roundofno()
{
    var Fractionalno = parseFloat(document.getElementById("Fractional-no").value);
    var decimalplaces = parseInt(document.getElementById("decimal_places").value);

    var Roundoffno = Fractionalno.toFixed(decimalplaces);

    document.getElementById("output4").innerText= Roundoffno ;
}

// Que no :5
function currentDay(){
    // Create a new Date object
    const currentDate = new Date();

    // Array of days of the week
    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    // Get the current day of the week
    const dayOfWeek = daysOfWeek[currentDate.getDay()];

    // Get the current hour, minute, and second
    const hours = currentDate.getHours();
    const minutes = currentDate.getMinutes();
    const seconds = currentDate.getSeconds();

    // Convert the hour to AM/PM format
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const formattedHours = hours % 12 || 12; // Convert 24-hour format to 12-hour format

    // Format the time with leading zeros if necessary
    const formattedTime = `${formattedHours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')} ${ampm}`;

    // Display the current day and time
    console.log(`Today is: ${dayOfWeek}. Current time is: ${formattedTime}`);
    document.getElementById("output5").textContent = `Today is: ${dayOfWeek}. Current time is: ${formattedTime}`;
  }